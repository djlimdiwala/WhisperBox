package com.whisperbox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhisperBoxApplicationTests {

	@Test
	void contextLoads() {
	}

}
